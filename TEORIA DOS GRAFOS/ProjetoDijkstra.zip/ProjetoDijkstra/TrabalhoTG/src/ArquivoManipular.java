import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

public class ArquivoManipular {

	//
	// Variavel de acesso ao arquivo.
	//
	private RandomAccessFile io_file = null;

	//
	// Variavel que conterá o nome do arquivo.
	//
	private String is_filename = null;

	//
	// Variavel que indicará o final do arquivo.
	//
	private int in_end_of_file = -1;

	//
	// Construtor padrão passando o nome do arquivo.
	//
	public ArquivoManipular(final String as_filename) throws FileNotFoundException {
		
		is_filename = as_filename;

		//
		// Cria o arquivo e da acesso a leitura e escrita.
		//
		io_file = new RandomAccessFile(is_filename, "rw");
	}

	/**
	 * Método para ler uma determinada linha do arquivo.
	 * 
	 * @return
	 * @throws IOException
	 */
	public final String LerLinha() throws IOException {

		//
		// Guadará o resultado.
		//
		String ls_line = null;

		//
		// Se recebeu algo.
		//
		if (in_end_of_file < 0 && (ls_line = io_file.readLine()) != null
				&& (in_end_of_file = ls_line.indexOf(0x1A)) != 0) {
			//
			// Se não chegou no final do arquivo ...
			//
			if (in_end_of_file > 0) {

				//
				// Trunca as informações.
				//
				ls_line = ls_line.substring(0, in_end_of_file);
			}
		}

		//
		// Se chegou no final do arquivo.
		//
		else {
			ls_line = null;
		}

		//
		// Retorna a linha do arquivo ...
		//
		return (ls_line);
	}

	/**
	 * Método responsavel por escrever no arquivo.
	 * 
	 * @param as_filename
	 *            Nome do arquivo a ser escrito.
	 * @param as_text
	 *            Texto a ser escrevito no arquivo.
	 * @param ab_append
	 * @throws IOException
	 */
	public final static void Escrever(final String as_filename, final String as_text, final boolean ab_append)
			throws IOException {
		//
		// Abre o arquivo.
		//
		BufferedOutputStream lo_ops_file = new BufferedOutputStream(new FileOutputStream(as_filename, ab_append));

		try {
			//
			// Escreve os dados no arquivo.
			//
			lo_ops_file.write(as_text.concat("\r\n").getBytes());
		}

		finally {
			//
			// Fecha o arquivo.
			//
			lo_ops_file.close();
		}

	}
}
