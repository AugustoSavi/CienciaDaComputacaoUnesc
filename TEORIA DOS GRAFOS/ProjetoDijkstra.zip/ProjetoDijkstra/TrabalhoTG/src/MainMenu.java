import javax.swing.JFrame;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;


public class MainMenu extends JFrame {
	
	
	//cria a janela menu de onde pode seguir para configurações(wdConfig) ou buscar(wdBusca)
	Windows w = new Windows();
	
	private JButton btnConfig;
	private JButton btnBusca;
	private JButton btnSair;
	
	public MainMenu () {
		
		setTitle("Trabalho");
		setSize(200,200);
		setLayout(null);
		setResizable(false);
		setLocationRelativeTo(null);
		
		getContentPane().setBackground(Color.lightGray);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		menuInicio();

	}
	
	public void menuInicio() {
		
		btnConfig = new JButton("Configuração");
		
			btnConfig.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					w.wdConfig();
					
				
				}
			});
			btnConfig.setBounds(25, 10, 150, 30);
			btnConfig.setBackground(Color.white);
			getContentPane().add(btnConfig);
			
			btnBusca = new JButton("Busca");
			
				btnBusca.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						dispose();
						w.wdBusca();
						
					}
				});
				btnBusca.setBounds(25, 67, 150, 30);
				btnBusca.setBackground(Color.white);
				getContentPane().add(btnBusca);
		
			
		btnSair = new JButton("Sair"); 
		
			btnSair.addActionListener(new ActionListener() {
			
				@Override
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
		
			btnSair.setBounds(25, 125, 150, 30);
			btnSair.setBackground(Color.white);
			getContentPane().add(btnSair);
		
	}
	
}
