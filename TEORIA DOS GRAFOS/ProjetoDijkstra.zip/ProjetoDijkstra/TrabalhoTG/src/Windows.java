import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.io.FileNotFoundException;
import javax.swing.JCheckBox;

public class Windows extends JFrame{
	
	//ArquivoManipular archive = new ArquivoManipular("texto");
	
	private JButton btnVoltar_Busca;	//Botão de voltar
	private JButton btnVoltar_Config;	//Botão de voltar
	private JButton btnSalvar;			//Botão que salva as mudanças
	private JButton	btnBuscar; 			//busca os dados conforme
	private JButton	btnAdicionar;		//adiciona novas cidades a tabela é idicado pelo '+'
	private JButton	btnProcessar;		//processa os dados do arquivo
	
	private JLabel lblPasta;		
	private JLabel lblSucesso;		
	private JLabel lblErro;			
	private JLabel lblBuscar;
	private JLabel lblCodigo_Origem;
	private JLabel lblCodigo_Destino;
	private JLabel lblCidade_Origem;
	private JLabel lblCidade_Destino;
	private JLabel lblKM;
	private JLabel lblOrigem;
	private JLabel lblDestino;
	
	private JTextField txfPasta;	
	private JTextField txfSucesso;	
	private JTextField txfErro;		
	private JTextField txfBuscar;
	private JTextField txfCodigo_Origem;
	private JTextField txfCodigo_Destino;
	private JTextField txfCidade_Origem;
	private JTextField txfCidade_Destino;
	private JTextField txfKM;
	
	private JCheckBox cbAutomatico; //CheckBox que confirma rota automatica
	
	private JTable tblDados;
	private JScrollPane spnDados;
	private DefaultTableModel model;
	
	private String pesquisa =  ""; 			//Aramazena o valor a ser buscado
	private String Codigo_Origem = ""; 		//Armazenda o codigo da cidade origem
	private String Codigo_Destino = ""; 	//Armazenda o codigo da cidade destino
	private String Cidade_Origem = ""; 		//Armazena a cidade origem
	private String Cidade_Destino = ""; 	//Armazena a cidade destino
	private String KM = "";					//Armazena a kilometragem(peso do grafo)
	private String Delimitador = ";;;";
	private int cont = 0 ;

	
	//File file =new File("Test2.txt");
	

	//Janela que aparece na primeira execução do programa
	//Janela de configuração
	public void wdConfig() {
		
		
		setTitle("Configuração");
		setSize(300,300);
		setLayout(null);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.lightGray);
		setVisible(true);
		
//-----------------------------------LABELS-----------------------------------------
		
		lblPasta = new JLabel("Pasta:");
		lblPasta.setBounds(10, 15, 70, 25);
		getContentPane().add(lblPasta);

		lblSucesso = new JLabel("Sucesso:");
		lblSucesso.setBounds(10, 55, 70, 25);
		getContentPane().add(lblSucesso);
		
		lblErro = new JLabel("Erro:");
		lblErro.setBounds(10, 95, 70, 25);
		getContentPane().add(lblErro);
		
//----------------------------------TEXT FIELD--------------------------------------
		
		txfPasta = new JTextField();
		txfPasta.setBounds(100, 15, 185, 25);
		getContentPane().add(txfPasta);
		
		txfSucesso = new JTextField();
		txfSucesso.setBounds(100, 55, 110, 25);
		getContentPane().add(txfSucesso);
		
		txfErro = new JTextField();
		txfErro.setBounds(100, 95, 110, 25);
		getContentPane().add(txfErro);
		
//----------------------------------BUTTON-------------------------------------------
		
		btnVoltar_Config = new JButton("Voltar");
		btnVoltar_Config.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				new MainMenu().show();
				dispose();
				
			}
		});
		btnVoltar_Config.setBounds(175, 220, 100, 30);
		btnVoltar_Config.setBackground(Color.white);
		getContentPane().add(btnVoltar_Config);
		
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		btnSalvar.setBounds(25, 220, 100, 30);
		btnSalvar.setBackground(Color.white);
		getContentPane().add(btnSalvar);
	
//--------------------------------CHECK BOX---------------------------------------------
		
		cbAutomatico = new JCheckBox("Rota Automatica");
		cbAutomatico.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		cbAutomatico.setBounds(75, 150, 200, 50);
		cbAutomatico.setBackground(Color.lightGray);
		getContentPane().add(cbAutomatico);
		
		
	}
	
	/*Janela de busca aonde o usuario consegue 
	fazer a pesquisa, adicionar e remover cidades*/
	public void wdBusca() {
			
		setTitle("Busca");
		setSize(800,600);
		setLayout(null);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.lightGray);
		setVisible(true);
		
/*-----------------------------BOTÃO----------------------------------------*/
		
		btnBuscar = new JButton("Buscar");
		
		btnBuscar.setBounds(500, 25, 150, 30);
		btnBuscar.setBackground(Color.white);
		btnBuscar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		getContentPane().add(btnBuscar);
		
		btnAdicionar = new JButton("+");
		
		btnAdicionar.setBounds(740, 155, 50, 30);
		btnAdicionar.setBackground(Color.white);
		btnAdicionar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				Cidade_Origem = txfCidade_Origem.getText();
				Cidade_Destino = txfCidade_Destino.getText();
				Codigo_Origem = txfCodigo_Origem.getText();
				Codigo_Destino = txfCodigo_Destino.getText();
				KM = txfKM.getText();
				
				model.addRow(new String[] {Codigo_Origem, Cidade_Origem, Codigo_Destino, Cidade_Destino, KM});
				try {
						
				ArquivoManipular.Escrever("Teste2.txt",Codigo_Origem+Delimitador+Codigo_Destino+Delimitador+KM , true);
			
				//ArquivoManipular file = new ArquivoManipular("Teste2.txt");
			
			} catch (Exception c) {
				c.printStackTrace();
				}
			}
		});
		getContentPane().add(btnAdicionar);
		
		btnSalvar = new JButton("SALVAR");
		
		btnSalvar.setBounds(535, 515, 125, 30);
		btnSalvar.setBackground(Color.white);
		btnSalvar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					ArquivoManipular file = new ArquivoManipular("/home/augusto/snap/gitkraken/138/ProjetoDijkstra/Teste2.txt");//pega o diretorio do arquivo(maquina augusto)
					/*Qualquer coisa quando criar em salvar o arquivo vai ser criando ai vc clica com o botão direito encima dele e pega o path dele e substitui ali em cima */
					
					String linha = null;
					//int cont=0;
					
					
					while ((linha = file.LerLinha()) != null) {
					
						// System.out.println(linha);//printa no console as linhas do arquivo 
						// String texto_codigo[] = linha.split(Delimitador);//Separa a linha em um array contendo as informaçoes 
						// System.out.println(texto_codigo[0]);//codigo Origem
						// System.out.println(texto_codigo[1]);//codigo Destino
						// System.out.println(texto_codigo[2]);//KM
						cont++;
						
					}
					
					}catch(Exception i){
						i.printStackTrace();
					}

			}
		});
		getContentPane().add(btnSalvar);
		
		btnProcessar = new JButton("PROCESSAR");
		
		btnProcessar.setBounds(665, 515, 125, 30);
		btnProcessar.setBackground(Color.white);
		btnProcessar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				

				 try{
				 ArquivoManipular file = new ArquivoManipular("/home/augusto/snap/gitkraken/138/ProjetoDijkstra/Teste2.txt");//pega o diretorio do arquivo(maquina augusto)
				 /*Qualquer coisa quando criar em salvar o arquivo vai ser criando ai vc clica com o botão direito encima dele e pega o path dele e substitui ali em cima */
				
				 String linha = null;
				// int cont=0;
				 Dijkstra dijkstra  = new Dijkstra(8);

				 while ((linha = file.LerLinha()) != null) {
				

				 	String texto_codigo[] = linha.split(Delimitador);//Separa a linha em um array contendo as informaçoes 
				 	//texto_codigo[0]//codigo Origem
				 	//texto_codigo[1]//codigo Destino
				 	//texto_codigo[2]//KM
					dijkstra.inserirAresta(Integer.parseInt(texto_codigo[0]), Integer.parseInt(texto_codigo[1]), Integer.parseInt(texto_codigo[2]));
				 }
				 //Dijkstra dijkstra  = new Dijkstra(8);

				 dijkstra.menorCaminhoEncontrar(0,7);
				 
				 }catch(Exception i){
				 	i.printStackTrace();
				 }
			}
		});
		getContentPane().add(btnProcessar);
		
		btnVoltar_Busca = new JButton("Voltar");
		
		btnVoltar_Busca.setBounds(405, 515, 125, 30);
		btnVoltar_Busca.setBackground(Color.white);
		btnVoltar_Busca.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				new MainMenu().setVisible(true);
				
			}
		});
		getContentPane().add(btnVoltar_Busca);
		
/*-----------------------------LABEL---------------------------------------*/
		
		
		lblBuscar = new JLabel("Buscar:");
		lblBuscar.setBounds(10, 25, 75, 30);
		getContentPane().add(lblBuscar);
		
		lblCodigo_Origem = new JLabel("Código:");
		lblCodigo_Origem.setBounds(10, 75, 75, 30);
		getContentPane().add(lblCodigo_Origem);
		
		lblCodigo_Destino = new JLabel("Código:");
		lblCodigo_Destino.setBounds(10, 115, 75, 30);
		getContentPane().add(lblCodigo_Destino);
		
		lblCidade_Origem = new JLabel("Cidade:");
		lblCidade_Origem.setBounds(200, 75, 75, 30);
		getContentPane().add(lblCidade_Origem);
		
		lblCidade_Destino = new JLabel("Cidade:");
		lblCidade_Destino.setBounds(200, 115, 75, 30);
		getContentPane().add(lblCidade_Destino);
		
		lblKM = new JLabel("KM:");
		lblKM.setBounds(36, 155, 75, 30);
		getContentPane().add(lblKM);
		
		lblOrigem = new JLabel("(ORIGEM)");
		lblOrigem.setBounds(500, 75, 75, 30);
		getContentPane().add(lblOrigem);
		
		lblDestino = new JLabel("(DESTINO)");
		lblDestino.setBounds(500, 115, 75, 30);
		getContentPane().add(lblDestino);
		
/*-----------------------------TEXT FIELD-------------------------------------*/
		
		txfBuscar = new JTextField();
		txfBuscar.setBounds(85, 25, 400, 30);
		getContentPane().add(txfBuscar);
		
		txfCodigo_Origem = new JTextField();
		txfCodigo_Origem.setBounds(85, 75, 95, 30);
		getContentPane().add(txfCodigo_Origem);
		
		txfCodigo_Destino = new JTextField();
		txfCodigo_Destino.setBounds(85, 115, 95, 30);
		getContentPane().add(txfCodigo_Destino);
		
		txfCidade_Origem = new JTextField();
		txfCidade_Origem.setBounds(270, 75, 215, 30);
		getContentPane().add(txfCidade_Origem);
		
		txfCidade_Destino = new JTextField();
		txfCidade_Destino.setBounds(270, 115, 215, 30);
		getContentPane().add(txfCidade_Destino);
		
		txfKM = new JTextField();
		txfKM.setBounds(85, 155, 65, 30);
		getContentPane().add(txfKM);
		
/*-----------------------------TABLE-------------------------------------------*/


		model = new DefaultTableModel();
		model.addColumn("Codigo Origem");
		model.addColumn("Cidade Origem");
		model.addColumn("Codigo Destino");
		model.addColumn("Cidade Destino");
		model.addColumn("Distancia");

		tblDados = new JTable(model);
		spnDados = new JScrollPane(tblDados);

		spnDados.setBounds(10, 200, 780, 300);
		getContentPane().add(spnDados);

	}
	
}
