
public class TestarAviao {
    public static void main(String args[]){
        
       Aviao avi=new Aviao(); 
       
       avi.nrPassageiros=10;
       
       avi.velocidadeAtual=600;
       
    }
}
