/*Elabore um algoritmo que imprima todos os números de 1 até 100.*/
public class Ex6 {
    public static void main(String[] args) {
        for(int i=1;i<101;i++){
            System.out.println(""+i);
        }
    }
    
}
