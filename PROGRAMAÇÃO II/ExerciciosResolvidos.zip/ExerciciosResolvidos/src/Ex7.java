/*Elabore um algoritmo que imprima todos os números de 100 até 1*/
public class Ex7 {
    public static void main(String[] args) {
    for(int i=100;i>0;i--){
            System.out.println(""+i);
        }
    }
    
}

