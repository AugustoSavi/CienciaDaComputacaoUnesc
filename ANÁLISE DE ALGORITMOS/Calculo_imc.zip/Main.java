
package calculo_imc;

public class Main {
	
    
   public static void main(String[] args) {
           Calculo_IMC calc = new Calculo_IMC(); 
           
           while (true){
 
        	   if (calc.menu()==2){
        		   break;}
      }
   }
}
