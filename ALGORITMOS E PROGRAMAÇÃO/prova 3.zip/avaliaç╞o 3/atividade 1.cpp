#include<conio.h>
#include<stdio.h>
main(){
	char nome[40],mat[2][5],i,j,aux;
	int 
	for(i=0;i<2;i++){
		for(j=0;j<5;j++){
			printf("informe o nome:")
			scanf("%c",&)
		}
	}
	
	
	
	
	// (Valor 3,5) Elabore um algoritmo que leia o nome, estado de nascimento (1 - Paran�, 2 - Santa
//Catarina e 3 - Rio Grande do Sul), sexo (M ou F) e profiss�o de 10 pessoas que residem na regi�o
//sul do Brasil e os armazene em uma matriz. 

//Considere a seguinte tabela para a profiss�o:
//Codigo Profiss�o

//10 Advogado
//20 Engenheiro
//30 Medico

//Em seguida o algoritmo dever� calcular e imprimir:
	
//a) Nome das pessoas que nasceram em Santa Catarina e s�o engenheiros(as)
//b) Quantidade de homens advogados
//c) Nome de todas as mulheres m�dicas nascidas no Rio Grande do Sul
}

